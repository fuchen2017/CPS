<?php
	session_start();
//包含需求檔案 ------------------------------------------------------------------------
	include("../class/common_lite.php");
if($_SESSION['loginType'] > ''){
	//宣告變數 ----------------------------------------------------------------------------
	$ODb = new run_db("mysql",3306);      //建立資料庫物件	
	if($_POST['keyNum'] != '' && $_POST['namedsc'] != '' && ($_SESSION['loginType'] == 'TEACHER' || $_SESSION['loginType'] == 'ADMIN')){
		if($_SESSION['loginType'] == "TEACHER"){
			$andDsc=",`create_user_type`='TEACHER',`create_user`='".$_SESSION['swTeacherNum']."'";
		}
		if($_SESSION['loginType'] == "ADMIN"){
			$andDsc=",`create_user_type`='ADMIN'";
		}
		
		//增加單元
		$nowdate =  date("Y-m-d H:i",time());
		$up_dsc ="
		insert into `operation_data` 
		set 
		`c_title`='".$_POST['namedsc']."',
		`main_data_num`='".$_POST['keyNum']."',
		`c_dsc`='".$_POST['powerdsc']."',
		`up_date`='".$nowdate."'".$andDsc;
		$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");
		
	}
	echo $nowdate;
	$ODb->close();
}
?>