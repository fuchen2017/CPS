<?php
	session_start();
//包含需求檔案 ------------------------------------------------------------------------
	include("../class/common_lite.php");
	if($_SESSION['loginType'] == 'ADMIN'){
		//宣告變數 ----------------------------------------------------------------------------
		$ODb = new run_db("mysql",3306);      //建立資料庫物件
		$sqlDsc ="select * from `teacherdata`";
		$res = $ODb->query($sqlDsc) or die("更新資料出錯，請聯繫管理員。");	
		while($row = mysql_fetch_array($res)){
			$dataArray = array(
				'num'=>$row['num'],
				'c_name'=>$row['c_name']			
			);	
			$getDataArray[] = $dataArray;
		}
		$ODb->close();		
	}
?>
<li id="teacherLi<?php echo $_POST['teacherNum'];?>">
<select name="teacherSwitch<?php echo $_POST['teacherNum'];?>" id="teacherSwitch<?php echo $_POST['teacherNum'];?>">
<?php
for($x=0;$x<count($getDataArray);$x++){?>
<option value="<?php echo $getDataArray[$x]['num'];?>" ><?php echo $getDataArray[$x]['c_name'];?></option>
<?php
}
?>
</select><input type="button" value="刪除" onclick="delTeahcer(<?php echo $_POST['teacherNum'];?>)">
</li>