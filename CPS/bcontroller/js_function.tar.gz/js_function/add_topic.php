<?php
	session_start();
//包含需求檔案 ------------------------------------------------------------------------
	include("../class/common_lite.php");
	if($_SESSION['loginType'] == 'ADMIN'){
		//宣告變數 ----------------------------------------------------------------------------
		$ODb = new run_db("mysql",3306);      //建立資料庫物件
		$sqlDsc ="select * from `main_data`";
		$res = $ODb->query($sqlDsc) or die("更新資料出錯，請聯繫管理員。");	
		while($row = mysql_fetch_array($res)){
			$dataArray = array(
				'num'=>$row['num'],
				'c_title'=>$row['c_title']			
			);	
			$getDataArray[] = $dataArray;
		}
		$ODb->close();		
	}
?>
<li id="topicLi<?php echo $_POST['topicNum'];?>">
排序:<input type="number" name="topicOrder<?php echo $_POST['topicNum'];?>" min=0 max=99 value="99" maxlength="2">
<select name="topicSwitch<?php echo $_POST['topicNum'];?>" id="topicSwitch<?php echo $_POST['topicNum'];?>">
<?php
for($x=0;$x<count($getDataArray);$x++){?>
<option value="<?php echo $getDataArray[$x]['num'];?>" ><?php echo $getDataArray[$x]['c_title'];?></option>
<?php
}
?>
</select><input type="button" value="刪除" onclick="delNewTopic(<?php echo $_POST['topicNum'];?>)">
</li>