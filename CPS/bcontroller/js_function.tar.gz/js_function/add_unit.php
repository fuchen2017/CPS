<?php
	session_start();
//包含需求檔案 ------------------------------------------------------------------------
	include("../class/common_lite.php");
	if($_SESSION['loginType'] > ''){
		//宣告變數 ----------------------------------------------------------------------------
		$ODb = new run_db("mysql",3306);      //建立資料庫物件	
		if($_POST['keyNum'] != '' && ($_SESSION['loginType'] == 'TEACHER' || $_SESSION['loginType'] == 'ADMIN')){
			if($_SESSION['loginType'] == 'TEACHER'){
			$whereDsc = ",`create_user`='".$_SESSION['swTeacherNum']."',`create_user_type`='TEACHER',`is_open`=1";
			}else{
			$whereDsc = ",`create_user_type`='ADMIN',`is_open`=1";
			}
			
			//增加單元
			$nowdate =  date("Y-m-d H:i",time());
			$up_dsc ="
			insert into `main_data` 
			set 
			`c_title`='".$_POST['keyNum']."',
			`c_module_type`='".$_POST['ModuleType']."',
			`c_speech_type`='".$_POST['c_speech_type']."',
			`c_test_time`='".$_POST['c_test_time']."',
			`up_date`='".$nowdate."'".$whereDsc;
			$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");		
		}
		$ODb->close();
	}
	echo "ok";
	

?>