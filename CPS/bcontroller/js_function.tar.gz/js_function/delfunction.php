<?php
//包含需求檔案 ------------------------------------------------------------------------
include("../class/common_lite.php");
//宣告變數 ----------------------------------------------------------------------------
$ODb = new run_db("mysql",3306);      //建立資料庫物件	
	
//Url解碼
	foreach($_GET as $key => $value)
	{
		$_GET[$key] = base64_decode($value);
	}
if(is_numeric($_GET['keyNum'])){
switch($_GET['tables']){
case "test_time_list"://刪除試題清單
	$sql ="delete from `test_time_teacher` where `f_num`='".$_GET['keyNum']."'";
	$ODb->query($sql);
	$sql ="delete from `test_time_topic` where `f_num`='".$_GET['keyNum']."'";
	$ODb->query($sql);
	$sql ="delete from `test_time_list` where `num`='".$_GET['keyNum']."'";
	$ODb->query($sql);
	echo "ok";	
break;
case "main_data"://刪除單元	
	$sql ="delete from `operation_data` where `main_data_num`='".$_GET['keyNum']."'";
	$ODb->query($sql);
	$sql ="delete from `main_data` where `num`='".$_GET['keyNum']."'";
	$ODb->query($sql);
	echo "ok";
break;
case "operation_data"://刪除作業	
	$sql ="delete from `operation_data` where `num`='".$_GET['keyNum']."'";
	$ODb->query($sql);
	echo "ok";
break;
case "questions_data"://刪除試題
	$sql_1 ="delete from `speak_data` where `questions_data_num`='".$_GET['keyNum']."'";
	$ODb->query($sql_1);
	$sql ="delete from `questions_data` where `num`='".$_GET['keyNum']."'";
	$ODb->query($sql);
	echo "ok";
break;
case "teacherData"://刪除教師資料及所託管的學生資料
	$sql_1 ="delete from `studentdata` where `teacherdataNum`='".$_GET['keyNum']."'";
	$ODb->query($sql_1);
	$sql_1 ="delete from `teacherdata` where `num`='".$_GET['keyNum']."'";
	$ODb->query($sql_1);
break;
case "studentData"://刪除學生資料
	$sql_1 ="delete from `studentdata` where `num`='".$_GET['keyNum']."'";
	$ODb->query($sql_1);
break;
default:
break;
}
}	
$ODb->close();

?>