<?php
session_start();
//包含需求檔案 ------------------------------------------------------------------------
include("../class/common_lite.php");
//if($_SESSION['zeroteamzero'] == 'IS_LOGIN'){
//宣告變數 ----------------------------------------------------------------------------
$ODb = new run_db("mysql",3306);      //建立資料庫物件
if($_SESSION['loginType'] == ''){

}else{
	$nowdate =  date("Y-m-d H:i",time());
	$sql_dsc = "delete from `share_data` where `mainData_num`=".$_POST['keyNum'];
	switch($_SESSION['loginType']){
		case "ADMIN":
			if($_POST['keyNum'] != '' && is_numeric($_POST['keyNum'])){
				$sql_dsc.= " and `user_type`='ADMIN' ";
				$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");	
				echo 'ok';
			}else{
				echo 'ok';
			}
		break;
		case "TEACHER":
			if($_POST['keyNum'] != '' && is_numeric($_POST['keyNum'])){
				$sql_dsc.= " and `user_type`='TEACHER' and `user_num`= ".$_SESSION['swTeacherNum'];
				$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");	
				echo 'ok';
			}else{
				echo 'ok';
			}		
		break;
		default:
		echo 'ok';
		break;		
	}
}	
$ODb->close();

?>