<?php
session_start();
//包含需求檔案 ------------------------------------------------------------------------
include("../class/common_lite.php");
//if($_SESSION['zeroteamzero'] == 'IS_LOGIN'){
//宣告變數 ----------------------------------------------------------------------------
$viewType = false;
if($_GET['viewType']!=''){
$viewType = true;
}

$ODb = new run_db("mysql",3306);      //建立資料庫物件	
if($_GET['keyNum'] != '' || $_GET['pcSerial'] != ''){
	if($_GET['keyNum'] != '' && $_GET['pcSerial'] != ''){//模組
		$up_dsc ="select * from `speak_data` where `questions_data_num`='".$_GET['keyNum']."' and `c_user_type`=1 and `pc_serial`='".$_GET['pcSerial']."' and `c_dsc_type`='".$_GET['dscType']."'";
		$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");	
		while($row = mysql_fetch_array($res)){
			if($viewType){
			$c_dsc="";
			}else{
			$c_dsc=$row['c_dsc'];
			}
			if($row['c_head_name']!=''){
				$head_name_dsc = $row['c_head_name'].':';//頭像名稱
			}else{
				$head_name_dsc = '';//頭像名稱
			}
			//判斷要用哪個頭像圖片
					switch($row['c_head_type']){
						case "1":
							$img_dsc='userf2.png';
						break;
						case "2":
							$img_dsc='userm1.png';
						break;
						case "3":
							$img_dsc='userm2.png';
						break;
						default:
							$img_dsc='userf1.png';
						break;
					
					}
					
			
			$pc_html .= '
			<div class="chat-1">
			<!--<IFRAME src="robot_img.php?dsc='.$c_dsc.'&head_type='.$row['c_head_type'].'" width="160"  scrolling="no" frameborder="0"></IFRAME>-->
			
			<img src="./images/'.$img_dsc.'">	<!-- 電腦對話頭像暫時關閉語音功能改成img頭像	-->			
			<ul><li onclick="replace_pc_speech(\''.$row['c_dsc'].'\',\''.$row['c_head_type'].'\')">'.$head_name_dsc.$row['c_dsc'].'</li></ul>
			</div>';
			if($row['speech_del_time']>0){
			$speech_del_time = $row['speech_del_time']."000";
			}else{
			$speech_del_time = $row['speech_del_time'];
			}
			
		}
	}else{//選項式對話
		$up_dsc ="select * from `speak_data` where `num`='".$_GET['keyNum']."'";
		$data['up_dsc0'] =$up_dsc;
		$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");
		while($row = mysql_fetch_array($res)){
			$questions_data_num	= $row['questions_data_num'];
			$c_dsc_type	= $row['c_dsc_type'];
			$pc_serial = $row['pc_serial'];
			$up_dsc ="select * from `speak_data` where `questions_data_num`='".$questions_data_num."' and `c_dsc_type`='".$c_dsc_type."' and `c_user_type`=1 and `pc_serial`='".$pc_serial."'";
			$res_1 = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");
			while($row_1 = mysql_fetch_array($res_1)){
			if($viewType){
			$c_dsc="";
			}else{
			$c_dsc=$row_1['c_dsc'];
			}
			if($row_1['c_head_name']!=''){
				$head_name_dsc = $row_1['c_head_name'].':';//頭像名稱
			}else{
				$head_name_dsc = '';//頭像名稱
			}
			
			//判斷要用哪個頭像圖片
			switch($row_1['c_head_type']){
				case "1":
					$img_dsc='userf2.png';
				break;
				case "2":
					$img_dsc='userm1.png';
				break;
				case "3":
					$img_dsc='userm2.png';
				break;
				default:
					$img_dsc='userf1.png';
				break;
			
			}
					
				$pc_html .= '
					<div class="chat-1">
					<!--	<IFRAME src="robot_img.php?dsc='.$c_dsc.'&head_type='.$row_1['c_head_type'].'" width="160"  scrolling="no" frameborder="0"></IFRAME>	-->
					
					<img src="./images/'.$img_dsc.'">	<!-- 電腦對話頭像暫時關閉語音功能改成img頭像	-->					
					<ul><li onclick="replace_pc_speech(\''.$row_1['c_dsc'].'\',\''.$row_1['c_head_type'].'\')">'.$head_name_dsc.$row_1['c_dsc'].'</li></ul>
					</div>';
				if($row_1['speech_del_time']>0){
				$speech_del_time = $row_1['speech_del_time']."000";
				}else{
				$speech_del_time = $row_1['speech_del_time'];
				}
			}
		}
	}

	$data['keyNum'] = $_GET['keyNum'];
	$data['pcSerial'] = $_GET['pcSerial'];
	$data['pc_html'] = $pc_html;
	$data['speech_del_time'] = $speech_del_time;
	$data['dscType'] = $_GET['dscType'];	
	echo json_encode($data);
}
$ODb->close();

?>