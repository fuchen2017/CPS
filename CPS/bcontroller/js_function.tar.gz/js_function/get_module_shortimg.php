<?php
session_start();
//包含需求檔案 ------------------------------------------------------------------------
include("../class/common_lite.php");
//if($_SESSION['zeroteamzero'] == 'IS_LOGIN'){
//宣告變數 ----------------------------------------------------------------------------
$ODb = new run_db("mysql",3306);      //建立資料庫物件	
if($_POST['keyNum'] != '' && $_POST['typeDsc'] != ''){
	$html_dsc ="";

	switch($_POST['typeDsc']){
	case "science":
	$table = "science_module_list";
	break;
	case "mathematics":
	$table = "mathematics_module_list";
	break;
	case "read":
	$table = "read_module_list";
	break;
	default:
	$table="";
	break;
	}
	if($table !=''){
	$up_dsc ="select * from `".$table."` where `c_type`='".$_POST['c_type']."'";
		$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");
		while($row = mysql_fetch_array($res)){
			$html_dsc.='<li><div class="model"><img src="./shortImg/'.$row['c_short_img'].'"></div><a  class="button" title="'.$row['c_title'].'" onclick="sw_shortimg(\''.$row['c_short_img'].'\','.$_POST['keyNum'].','.$row['num'].')">'.$row['c_title'].'</a></li>';
		}
	}else{
		echo '';
	}		
	echo $html_dsc;
}
$ODb->close();
?>