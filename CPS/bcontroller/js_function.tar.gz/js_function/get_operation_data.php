<?php
session_start();
//包含需求檔案 ------------------------------------------------------------------------
include("../class/common_lite.php");
include("../module_function/science.php");//科學模組
include("../module_function/common_use.php");//通用模組

$viewType = false;
if($_GET['viewType']!=''){
$viewType = true;
}


//if($_SESSION['zeroteamzero'] == 'IS_LOGIN'){
//宣告變數 ----------------------------------------------------------------------------
$ODb = new run_db("mysql",3306);      //建立資料庫物件	
if($_GET['keyNum'] != '' || $_GET['pcSerial'] != ''){
	//先紀錄一下現有能力指標值
	if($_GET['getPowerKey']!=''){
		$dsc = '';
		$up_dsc ="select * from `speak_data` where `num`='".$_GET['getPowerKey']."' and `c_power_dsc`>''";
		$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");
		if(mysql_num_rows($res)==1){
			while($row = mysql_fetch_array($res)){
				$allvalueArray = explode(',',$_SESSION['testPowerValue']);
				$allvalueArray[$row['c_power_dsc']] = $allvalueArray[$row['c_power_dsc']] + $row['c_power_number'];
				foreach($allvalueArray as $value){
				$dsc .=$value.",";
				}
				$dsc = substr($dsc,0,-1);
				$_SESSION['testPowerValue'] =$dsc;
			}
		}
	}
	
	//再來處理下一步驟
	if($_GET['keyNum'] != '' && $_GET['pcSerial'] != ''){
	$up_dsc ="select * from `speak_data` where `questions_data_num`='".$_GET['keyNum']."' and `c_user_type`=1 and `pc_serial`='".$_GET['pcSerial']."' and `c_dsc_type`='".$_GET['dscType']."'";	
	}else{
	$up_dsc ="select * from `speak_data` where `num`='".$_GET['keyNum']."'";
	}
	$data_array['sql_dsc'] = $up_dsc;
	$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");
if(mysql_num_rows($res)>0){
	while($row = mysql_fetch_array($res)){
		$questions_data_num	= $row['questions_data_num'];
		$c_dsc_type	= $row['c_dsc_type'];
		$pc_serial = $row['pc_serial'];
	}
	
	//取得operation_data_num 現在的作業num
	$up_dsc ="select * from `questions_data` where `num`='".$questions_data_num."'";
	$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");
	while($row = mysql_fetch_array($res)){
		$operation_data_num	= $row['operation_data_num'];
	}
	
	//取得next_operation_data_num 下一個作業num
	$next_operation_data_num='';
	$up_dsc ="select `main_data_num` from `operation_data` where `num`='".$operation_data_num."'";
	$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");
	while($row = mysql_fetch_array($res)){
		$main_data_num	= $row['main_data_num'];
		$up_dsc ="select `num` from `operation_data` where `num`>'".$operation_data_num."' and `main_data_num`='".$main_data_num."' order by `num` limit 1";
		$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");
		while($row = mysql_fetch_array($res)){
			$next_operation_data_num = $row['num'];
		}		
	}
	
	
	//取得下一試題的num
	$up_dsc ="select * from `questions_data` where `num`>'".$questions_data_num."' and `operation_data_num`='".$operation_data_num."' order by `num` limit 1";
	$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");
	while($row = mysql_fetch_array($res)){
		$next_questions_data_num = $row['num'];		
	}
	
	
	$up_dsc ="select * from `speak_data` where `pc_serial`='".$pc_serial."' and `questions_data_num`='".$questions_data_num."' and `c_dsc_type`=".$c_dsc_type ." and `c_user_type`=1";
	$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");
	if(mysql_num_rows($res)>0){
		while($row = mysql_fetch_array($res)){
			$c_sw_type = $row['c_sw_type'];
		}
		switch($c_sw_type){
			case "0"://第二會話
				$data_array['type_dsc'] ="talk2";
				$data_array['re_code'] = get_talk($questions_data_num,1);
				$data_array['step_dsc'] = getTalkStepDsc($questions_data_num,1);
				$data_array['hideModule'] = getHideModule($questions_data_num,1);
				$data_array['hideModuleBtnDsc'] = getHideModuleBtnDsc($questions_data_num,1);				
				$data_array['module_dsc'] = get_module_dsc($questions_data_num,1);
				$data_array['warning_time'] = get_warning_time($questions_data_num,1);				
				$data_array['warning_dsc'] = get_warning_dsc($questions_data_num,1);
				$data_array['has_module'] = get_has_module($questions_data_num,1);
				$data_array['autoRunData'] = get_autoRunData($questions_data_num,1);
				echo json_encode($data_array);
			break;
			case "1"://第三會話
				$data_array['type_dsc'] ="talk3";
				$data_array['re_code'] = get_talk($questions_data_num,2);
				$data_array['step_dsc'] = getTalkStepDsc($questions_data_num,2);
				$data_array['module_dsc'] = get_module_dsc($questions_data_num,2);
				$data_array['hideModule'] = getHideModule($questions_data_num,2);
				$data_array['hideModuleBtnDsc'] = getHideModuleBtnDsc($questions_data_num,2);				
				$data_array['warning_time'] = get_warning_time($questions_data_num,2);				
				$data_array['warning_dsc'] = get_warning_dsc($questions_data_num,2);	
				$data_array['has_module'] = get_has_module($questions_data_num,2);
				$data_array['autoRunData'] = get_autoRunData($questions_data_num,2);
				echo json_encode($data_array);
			break;
			case "2"://下一個試題
				$data_array['type_dsc'] ="next_q";
				$data_array['mission_dsc'] = get_mission_dsc($operation_data_num,$questions_data_num);
				$data_array['re_code'] = get_talk($next_questions_data_num,0);	
				$data_array['step_dsc'] = getTalkStepDsc($next_questions_data_num,0);
				$data_array['hideModule'] = getHideModule($next_questions_data_num,0);
				$data_array['hideModuleBtnDsc'] = getHideModuleBtnDsc($next_questions_data_num,0);
				$data_array['module_dsc'] = get_module_dsc($next_questions_data_num,0);
				$data_array['warning_time'] = get_warning_time($next_questions_data_num,0);				
				$data_array['warning_dsc'] = get_warning_dsc($next_questions_data_num,0);
				$data_array['has_module'] = get_has_module($next_questions_data_num,0);
				$data_array['autoRunData'] = get_autoRunData($next_questions_data_num,0);
				echo json_encode($data_array);
			break;
			case "3"://下一個作業
				$data_array['type_dsc'] ="next_w";
				$questions_data_num = get_first_questions_data_num($next_operation_data_num);
				if($questions_data_num !=''){
					$data_array['mission_dsc'] = get_first_mission_dsc($next_operation_data_num,$questions_data_num);
					$data_array['re_code'] = get_talk($questions_data_num,0);	
					$data_array['step_dsc'] = getTalkStepDsc($questions_data_num,0);
					$data_array['hideModule'] = getHideModule($questions_data_num,0);
					$data_array['hideModuleBtnDsc'] = getHideModuleBtnDsc($questions_data_num,0);					
					$data_array['module_dsc'] = get_module_dsc($questions_data_num,0);
					$data_array['warning_time'] = get_warning_time($questions_data_num,0);				
					$data_array['warning_dsc'] = get_warning_dsc($questions_data_num,0);
					$data_array['has_module'] = get_has_module($questions_data_num,0);
					$data_array['autoRunData'] = get_autoRunData($questions_data_num,0);
				}
				echo json_encode($data_array);
			break;
			case "4"://結束
				$data_array['type_dsc'] ="end";
				echo json_encode($data_array);
			break;
			case "5"://第四會話
				$data_array['type_dsc'] ="talk4";
				$data_array['re_code'] = get_talk($questions_data_num,3);
				$data_array['step_dsc'] = getTalkStepDsc($questions_data_num,3);
				$data_array['hideModule'] = getHideModule($questions_data_num,3);
				$data_array['hideModuleBtnDsc'] = getHideModuleBtnDsc($questions_data_num,3);
				$data_array['module_dsc'] = get_module_dsc($questions_data_num,3);
				$data_array['warning_time'] = get_warning_time($questions_data_num,3);				
				$data_array['warning_dsc'] = get_warning_dsc($questions_data_num,3);
				$data_array['has_module'] = get_has_module($questions_data_num,3);
				$data_array['autoRunData'] = get_autoRunData($questions_data_num,3);
				
				echo json_encode($data_array);
			break;
			case "6"://第一會話
				$data_array['type_dsc'] ="talk1";
				$data_array['re_code'] = get_talk($questions_data_num,0);
				$data_array['step_dsc'] = getTalkStepDsc($questions_data_num,0);
				$data_array['hideModule'] = getHideModule($questions_data_num,0);
				$data_array['hideModuleBtnDsc'] = getHideModuleBtnDsc($questions_data_num,0);				
				$data_array['module_dsc'] = get_module_dsc($questions_data_num,0);
				$data_array['warning_time'] = get_warning_time($questions_data_num,0);				
				$data_array['warning_dsc'] = get_warning_dsc($questions_data_num,0);
				$data_array['has_module'] = get_has_module($questions_data_num,0);
				$data_array['autoRunData'] = get_autoRunData($questions_data_num,0);
				
				echo json_encode($data_array);
			break;
			
			default:
			break;
		}
	}
}
}

function get_first_questions_data_num($operation_data_num){
	$ODb = new run_db("mysql",3306);      //建立資料庫物件
	$up_dsc ="select * from `questions_data` where `operation_data_num`='".$operation_data_num."' order by `num` limit 1";
	$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");
	while($row = mysql_fetch_array($res)){
		$num = $row['num'];		
	}
	$ODb->close();	
	
	return $num;

}

//取得階段說明
function getTalkStepDsc($getNum,$typeNum){
	$ODb = new run_db("mysql",3306);      //建立資料庫物件
	$sql_dsc ="select `c_dsc` from `step_dsc_data` where `questions_data_num`='".$getNum."' and `c_sw_type`=".$typeNum;
	$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");
	while($row = mysql_fetch_array($res)){
			$c_dsc = $row['c_dsc'];
	}
	$ODb->close();	
	
	return $c_dsc;
}

//是否隱藏模組
function getHideModule($getNum,$typeNum){
	$ODb = new run_db("mysql",3306);      //建立資料庫物件
	$sql_dsc ="select `hide_module_area` from `step_dsc_data` where `questions_data_num`='".$getNum."' and `c_sw_type`=".$typeNum;
	$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");
	while($row = mysql_fetch_array($res)){
		if( $row['hide_module_area']==1){ return true;}
		if( $row['hide_module_area']==0){ return false;}
	}
	$ODb->close();	
	
	return false;
}

function getHideModuleBtnDsc($getNum,$typeNum){
	$ODb = new run_db("mysql",3306);      //建立資料庫物件
	$sql_dsc ="select `hideModuleBtnDsc` from `step_dsc_data` where `questions_data_num`='".$getNum."' and `c_sw_type`=".$typeNum;
	$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");
	while($row = mysql_fetch_array($res)){
		 return $row['hideModuleBtnDsc'];
	}
	$ODb->close();	
	
	return "";
}

function get_talk($getNum,$typeNum){
	$ODb = new run_db("mysql",3306);      //建立資料庫物件	
	$dsc_first="";
	$dsc_0="";
	$dsc_1="";
	$dsc_2="";
	$total_talk="";
	$num = 0;
	$free_speech_type_dsc = "";//開放式對話的對話字串
	$free_speech_type_index= "";//開放式對話的key字串


	$sql_dsc ="select * from `speak_data` where `questions_data_num`='".$getNum."' and `c_dsc_type`=".$typeNum." order by `num` ";
	$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");
	if(mysql_num_rows($res)>0){
		while($row = mysql_fetch_array($res)){
			//使用者對話
			if($row['c_user_type'] == 0){
				$dsc_0.= "<li><input type='radio' subid='talk_radio' onclick=\"get_last_pcmsg('".$row['num']."');set_record('radio||speech_radio_".$num."');set_getPowerKey(".$row['num'].")\" name='speech_radio' id='speech_radio_".$num."' value='".$row['num']."' ><label for='speech_radio_".$num."'>".$row['c_dsc']."</label></li>";
				$num++;
				if($free_speech_type_dsc=="" && $free_speech_type_index==""){
					$free_speech_type_dsc.= $row['c_dsc'];
					$free_speech_type_index.= $row['num'];
				}else{
					$free_speech_type_dsc.= "<tw>".$row['c_dsc'];
					$free_speech_type_index.= "<tw>".$row['num'];
				}

			}
			
			//一開始電腦的對話
			if($row['c_user_type'] == 1){
				if($row['pc_serial']=="" && $row['c_dsc'] !=''){
					if($viewType){
						$c_dsc="";
					}else{
						$c_dsc=$row['c_dsc'];
					}
					if($row['c_head_name']!=''){
						$head_name_dsc = $row['c_head_name'].':';//頭像名稱
					}else{
						$head_name_dsc = '';//頭像名稱
					}
					
					//判斷要用哪個頭像圖片
					switch($row['c_head_type']){
						case "1":
							$img_dsc='userf2.png';
						break;
						case "2":
							$img_dsc='userm1.png';
						break;
						case "3":
							$img_dsc='userm2.png';
						break;
						default:
							$img_dsc='userf1.png';
						break;
					
					}
					
					$dsc_first = '
					<div class="chat-1" id="robot_dsc">
					<!--<IFRAME src="robot_img.php?dsc='.$c_dsc.'&head_type='.$row['c_head_type'].'" width="160"  scrolling="no" frameborder="0"></IFRAME>-->
					<img src="./images/'.$img_dsc.'">	<!-- 電腦對話頭像暫時關閉語音功能改成img頭像	-->
					<ul>
					<li onclick="replace_pc_speech(\''.$row['c_dsc'].'\',\''.$row['c_head_type'].'\')">'.$head_name_dsc.$row['c_dsc'].'</li>
					</ul>
					</div>
					';
				}
			}	
			
			//梅林
			if($row['c_user_type'] == 2){
				if($row['c_dsc'] !=''){					
					$dsc_2 = '
					<div class="chat-1">
					<img src="images/user2.png" />
					<li>'.$row['c_dsc'].'</li>
					</div>
					';
				}
			}		
		}
		if($_GET['speechtype']=="free"){
			$total_talk = $dsc_first.$dsc_2.'
			<script>
				free_speech_type_dsc="'.$free_speech_type_dsc.'";
				free_speech_type_index="'.$free_speech_type_index.'";
			</script>';
		}else{
			$total_talk = $dsc_first.'<div class="chat"><img src="images/user.png" /><ul>'.$dsc_0.'</ul></div>'.$dsc_2;
		}
	}
	$ODb->close();	
	
	return $total_talk;
}


//取現在試題的敘述
function get_first_mission_dsc($operation_data_num,$questions_data_num){
	$ODb = new run_db("mysql",3306);      //建立資料庫物件	
	$sql="select `c_title` from `operation_data` where `num`=".$operation_data_num." ";
	$res = $ODb->query($sql) or die("更新資料出錯，請聯繫管理員。");
	if(mysql_num_rows($res)>0){
		while($row = mysql_fetch_array($res)){
		return $row['c_title'];
		}
	}
	$ODb->close();	
	
	return "";
}

//取下一個試題的敘述
function get_mission_dsc($operation_data_num,$questions_data_num){
	$ODb = new run_db("mysql",3306);      //建立資料庫物件	
	$sql="select `c_title` from `operation_data` where `num`='".$operation_data_num."' limit 1";
	$res = $ODb->query($sql) or die("更新資料出錯，請聯繫管理員。");
	if(mysql_num_rows($res)>0){
		while($row = mysql_fetch_array($res)){
		return $row['c_title'];
		}
	}
	$ODb->close();	
	
	return "";
}

//取出會話的模組
function get_module_dsc($questions_data_num,$c_dsc_type){
	$ODb = new run_db("mysql",3306);      //建立資料庫物件	
	$module_html="";
	$sql_dsc="select * from  `speak_usemodule_data` where `questions_data_num`='".$questions_data_num."' and `c_dsc_type`=".$c_dsc_type;
	$res=$ODb->query($sql_dsc) or die("載入資料出錯，請聯繫管理員。");
	while($row = mysql_fetch_array($res)){
		switch($row['module_type']){
			case "science":
			$class_num = get_module_type($row['module_num']);

			if($row['ckedit_dsc'] !=''){//使用ckedit的資料
				$module_html = '
				<div class="science_'.$class_num.'">'.$row['ckedit_dsc'].'</div>
				<br>
				<div  id="show_msg_box"  class="show_msg_box" >
				'.$row['ckedit_dsc_memo'].'				
				</div>
				<script language="javascript">
				$(function(){
					//重新註冊登箱內的超連結
					$("#show_msg_box a").colorbox({width:"100%",height:"100%",iframe: true});
				});
				</script>
				';			
			}
			if($row['module_num'] !=''){//使用模組資料
				$other_html = get_downButton($row['btn_dsc'],$row['pc_serial'],$row['questions_data_num'],$row['c_dsc_type']);
				$module_html = '<div class="science_'.$class_num.'">'.get_science_module($row['module_num']).$other_html.'</div>';
			}
			break;
			default:
			break;

		}
	}
	$ODb->close();	
	
	return $module_html;
}

//取出警告啟動時間
function get_warning_time($questions_data_num,$c_dsc_type){
	$ODb = new run_db("mysql",3306);      //建立資料庫物件
	$warning_time=0;
	$module_html="";
	$sql_dsc="select `warning_time` from  `speak_usemodule_data` where `questions_data_num`='".$questions_data_num."' and `c_dsc_type`=".$c_dsc_type;
	$res=$ODb->query($sql_dsc) or die("載入資料出錯，請聯繫管理員。");
	while($row = mysql_fetch_array($res)){
		if($row['warning_time']>0){
			$warning_time=$row['warning_time']."000";
		}		
	}
	$ODb->close();		
	return $warning_time;
}


//取出警告訊息
function get_warning_dsc($questions_data_num,$c_dsc_type){
	$ODb = new run_db("mysql",3306);      //建立資料庫物件
	$warning_dsc='';
	$module_html="";
	$sql_dsc="select `warning_dsc` from  `speak_usemodule_data` where `questions_data_num`='".$questions_data_num."' and `c_dsc_type`=".$c_dsc_type;
	$res=$ODb->query($sql_dsc) or die("載入資料出錯，請聯繫管理員。");
	while($row = mysql_fetch_array($res)){
		$warning_dsc=$row['warning_dsc'];		
	}
	$ODb->close();
	return $warning_dsc;
}

//是否有使用module
function get_has_module($questions_data_num,$c_dsc_type){
	$ODb = new run_db("mysql",3306);      //建立資料庫物件
	$has_module=false;
	$module_html="";
	$sql_dsc="select `module_num` from  `speak_usemodule_data` where `questions_data_num`='".$questions_data_num."' and `c_dsc_type`=".$c_dsc_type;
	$res=$ODb->query($sql_dsc) or die("載入資料出錯，請聯繫管理員。");
	while($row = mysql_fetch_array($res)){
		if($row['module_num'] !=""){
			$has_module=true;
		}
	}
	$ODb->close();
	return $has_module;
}
$ODb->close();
?>