<?php
	session_start();

  //包含需求檔案 ------------------------------------------------------------------------
	include("../class/common_lite.php");
	//宣告變數 ----------------------------------------------------------------------------
	$ODb = new run_db("mysql",3306);      //建立資料庫物件
	$typeDSC = array('oneData'=>'num','totalData'=>'timelist_num');
	if($_SESSION['loginType'] == '' || !is_numeric($_POST['num']) || !isset($typeDSC[$_POST['swType']])){
		
	}else{
		switch($_SESSION['loginType']){
			case "ADMIN":
				$whereDsc = " where `".$typeDSC[$_POST['swType']]."`='".$_POST['num']."' ";
			break;
			case "TEACHER":
				$whereDsc = " where `".$typeDSC[$_POST['swType']]."`='".$_POST['num']."' ";
			break;
			case "STUDENT":
				$whereDsc = " where `".$typeDSC[$_POST['swType']]."`='".$_POST['num']."' and `student_user`='".$_SESSION['swStudentNum']."' and `create_user_type`='STUDENT' ";
			break;
			default:
			ri_jump("logout.php");
			break;		
		}	
		
			//取出測驗資料
		$sql_dsc = "select * from `opt_record` ".$whereDsc." order by `num` desc";//管理員資料
		$res=$ODb->query($sql_dsc) or die("載入資料出錯，請聯繫管理員。");
		if(mysql_num_rows($res)>0){
			$mainDataDSC = '';
			while($row = mysql_fetch_array($res)){
				//取得學生資料
				if($row['student_user']>0){
					$sql_dsc = "select * from `studentdata` where `num`='".$row['student_user']."'";//管理員資料
					$res_temp=$ODb->query($sql_dsc) or die("載入資料出錯，請聯繫管理員。");
					while($row_temp = mysql_fetch_array($res_temp)){
						$studentName = $row_temp['c_name'];
					}
				}
				//取得單元num
				$mainDataDSC .= "'".$row['main_data_num']."',";
				$powerDSCArray[] = $row['power_dsc'];
			}	
				//取得該單元下各指標的題目數量
				/* '0'=>'(A1) 發現團隊成員的觀點與能力',
				'1'=>'(B1) 建立問題的共同表述和協商問題的意義',
				'2'=>'(C1) 與團隊成員溝通將要或是正在執行的動作',
				'3'=>'(D1) 檢核與修訂相互的理解',
				'4'=>'(A2) 根據目標發現解決問題的互動型態',
				'5'=>'(B2) 辨認與描述須完成的工作',
				'6'=>'(C2) 訂定計畫',
				'7'=>'(D2) 檢核執行的結果與評價解決問題的成功與否',
				'8'=>'(A3) 理解解決問題所扮演的角色',
				'9'=>'(B3) 描述問題解決中所扮演的角色與團隊組織',
				'10'=>'(C3) 遵守制定的規則',
				'11'=>'(D3) 檢核、反饋與適應團隊組織和角色' */
				$abilityArray = array(//能力指標選項
					'0'=>0,
					'1'=>0,
					'2'=>0,
					'3'=>0,
					'4'=>0,
					'5'=>0,
					'6'=>0,
					'7'=>0,
					'8'=>0,
					'9'=>0,
					'10'=>0,
					'11'=>0
				);
				
if($mainDataDSC >''){
	//取出作業num
	$sql_dsc = "select * from `operation_data` where `main_data_num` in (".substr($mainDataDSC,0,-1).") ";
	$res_temp=$ODb->query($sql_dsc) or die("載入資料出錯，請聯繫管理員。");
	$operationDataDsc='';
	while($row_temp = mysql_fetch_array($res_temp)){
		$operationDataDsc .= "'".$row_temp['num']."',";
	}
	//取出會話num
	if($operationDataDsc>''){
	$operationDataDsc = substr($operationDataDsc,0,-1);
	$sql_dsc = "select * from `questions_data` where `operation_data_num` in (".$operationDataDsc.") ";
	$res_temp=$ODb->query($sql_dsc) or die("載入資料出錯，請聯繫管理員。");
	$questionsData='';
	while($row_temp = mysql_fetch_array($res_temp)){
		$questionsData[] = $row_temp['num'];
	}
	
	//計算分母
	if(count($questionsData)>0){
		for($x=0;$x<count($questionsData);$x++){	
			$sql_dsc = "select * from `speak_data` where `questions_data_num`='".$questionsData[$x]."' and `c_user_type`='0' and `c_power_dsc`>'' group by `c_power_dsc`";
			
			$res_temp=$ODb->query($sql_dsc) or die("載入資料出錯，請聯繫管理員。");
			while($row_temp = mysql_fetch_array($res_temp)){
				$y = $row_temp['c_power_dsc'];
				if(isset($abilityArray[$y])){
					$abilityArray[$y]++;
				}
			}
		}
	}
		
	//將學生測驗的能力值全部加總以後再來計算
	$powerDscArray = array(//能力指標選項
					'0'=>0,
					'1'=>0,
					'2'=>0,
					'3'=>0,
					'4'=>0,
					'5'=>0,
					'6'=>0,
					'7'=>0,
					'8'=>0,
					'9'=>0,
					'10'=>0,
					'11'=>0
				);
	
	foreach($powerDSCArray as $pValue){
		$tempArray =  explode(',',$pValue);//學生的測驗值
		foreach($tempArray as $tempKey => $tempValue){
		$powerDscArray[$tempKey] += $tempValue;
		}	
	}
	
	$correctRate = substr($correctRate,0,5);
	$tab0 = $powerDscArray[0]+$powerDscArray[1]+$powerDscArray[2]+$powerDscArray[3];
	$total0 = $abilityArray[0]+$abilityArray[1]+$abilityArray[2]+$abilityArray[3];//答對率的分母
	if($total0>0){
	$m0 = $tab0/($total0*2);
	$m0 = substr($m0,0,5);
	}else{
	if($abilityArray[0]>0 || $abilityArray[1]>0|| $abilityArray[2]>0||$abilityArray[3]>0){
	$m0='0';
	}else{$m0='無';}
	
	
	}
	$tab1 = $powerDscArray[4]+$powerDscArray[5]+$powerDscArray[6]+$powerDscArray[7];
	$total1 = $abilityArray[4]+$abilityArray[5]+$abilityArray[6]+$abilityArray[7];//答對率的分母
	if($total1>0){
	$m1 = $tab1/($total1*2);
	$m1 = substr($m1,0,5);
	}else{
	if($abilityArray[4]>0 || $abilityArray[5]>0|| $abilityArray[6]>0||$abilityArray[7]>0){
	$m1='0';
	}else{$m1='無';}
	
	}

	$tab2 = $powerDscArray[8]+$powerDscArray[9]+$powerDscArray[10]+$powerDscArray[11];
	$total2 = $abilityArray[8]+$abilityArray[9]+$abilityArray[10]+$abilityArray[11];//答對率的分母
	if($total2>0){
	$m2 = $tab2/($total2*2);
	$m2 = substr($m2,0,5);
	}else{
	if($abilityArray[8]>0 || $abilityArray[9]>0|| $abilityArray[10]>0||$abilityArray[11]>0){
	$m2='0';
	}else{$m2='無';}
	}
	
	$tab3 = $powerDscArray[0]+$powerDscArray[4]+$powerDscArray[8];
	$total3 = $abilityArray[0]+$abilityArray[4]+$abilityArray[8];
	if($total3>0){
	$m3 = $tab3/($total3*2);
	$m3 = substr($m3,0,5);
	}else{
	if($abilityArray[0]>0 || $abilityArray[4]>0|| $abilityArray[8]>0){
	$m3='0';
	}else{$m3='無';}
	}				
	$tab4 = $powerDscArray[1]+$powerDscArray[5]+$powerDscArray[9];
	$total4 = $abilityArray[1]+$abilityArray[5]+$abilityArray[9];
	if($total4>0){
	$m4 = $tab4/($total4*2);
	$m4 = substr($m4,0,5);
	}else{
	if($abilityArray[1]>0 || $abilityArray[5]>0|| $abilityArray[9]>0){
	$m4='0';
	}else{$m4='無';}
	}				
	$tab5 = $powerDscArray[2]+$powerDscArray[6]+$powerDscArray[10];
	$total5 = $abilityArray[2]+$abilityArray[6]+$abilityArray[10];
	if($total5>0){
	$m5 = $tab5/($total5*2);
	$m5 = substr($m5,0,5);
	}else{
	if($abilityArray[2]>0 || $abilityArray[6]>0|| $abilityArray[10]>0){
	$m5='0';
	}else{$m5='無';}
	}				
	
	$tab6 = $powerDscArray[3]+$powerDscArray[7]+$powerDscArray[11];
	$total6 = $abilityArray[3]+$abilityArray[7]+$abilityArray[11];
	if($total6>0){
	$m6 = $tab6/($total6*2);
	$m6 = substr($m6,0,5);
	}else{
	if($abilityArray[3]>0 || $abilityArray[7]>0|| $abilityArray[11]>0){
	$m6='0';
	}else{$m6='無';}
	}				
	
	
	//算各單元的平均率
	for($x=0;$x<12;$x++){
		$totalArray[$x]=0;
		if($abilityArray[$x]>0){
		$tempValue = $powerDscArray[$x]/($abilityArray[$x]*2);
		$totalArray[$x]=substr($tempValue,0,5);
		}
		
	}	
	}
}
				
				
				
				
				
				
		}
	}
	$ODb->close();
?>
<table width="100%" class="record">
<tr><td>學號:</td></tr>
<tr><td>班級:</td></tr>
<tr><td>姓名:<?php echo $studentName;?></td></tr>
<tr><td  height="20px" ></td></tr>
<tr><td  align="center" ><h1>團隊合作核心能力</td></tr>
<tr><td>
<table width="100%" class="record_list">
	<tr class="title">
		<td width="90%" align="center" >團隊合作核心能力</td>
		<td width="10%" align="center" >答對率</td>
	</tr>
	<tr>
		<td align="center">建立及維持相互的理解</td>
		<td align="center"><?php echo $m0;?></td>
	</tr>
	<tr>
		<td align="center">採取適當的行動解決問題</td>
		<td align="center"><?php echo $m1;?></td>
	</tr>
	<tr>
		<td align="center">建立及維持團隊合作</td>
		<td align="center"><?php echo $m2;?></td>
	</tr>	
</table>
</td></tr>
<tr><td  height="40px" ></td></tr>
<tr><td  align="center" ><h1>問題解決認知行為歷程</h1></td></tr>
<tr><td  >
<table width="100%"  class="record_list">
	<tr class="title">
		<td width="90%" align="center" >問題解決認知行為歷程</td>
		<td width="10%" align="center" >答對率</td>
	</tr>
	<tr>
		<td align="center">探究及理解</td>
		<td align="center"><?php echo $m3;?></td>
	</tr>
	<tr>
		<td align="center">表達及系統性闡述</td>
		<td align="center"><?php echo $m4;?></td>
	</tr>
	<tr>
		<td align="center">計畫並執行</td>
		<td align="center"><?php echo $m5;?></td>
	</tr>	
	<tr>
		<td align="center">監控及反思</td>
		<td align="center"><?php echo $m6;?></td>
	</tr>	
</table>
</td></tr>
<tr><td  height="40px" ></td></tr>
<tr><td  align="center" ><h1>合作問題解決能力素養</h1></td></tr>
<tr><td  >
<table width="100%" border="1" class="record_list">
<tr class="title">
	<td width="90%" align="center" >合作問題解決能力素養</td>
	<td width="10%" align="center" >答對率</td>
</tr>

<tr><td>(A1) 發現團隊成員的觀點與能力</td><td><?php if($totalArray[0]>0){echo $totalArray[0];}else{if($abilityArray[0]==0){echo '無';}else{echo '0';}}?></td></tr>
<tr><td>(B1) 建立問題的共同表述和協商問題的意義</td><td><?php if($totalArray[1]>0){echo $totalArray[1];}else{if($abilityArray[1]==0){echo '無';}else{echo '0';}}?></td></tr>
<tr><td>(C1) 與團隊成員溝通將要或是正在執行的動作</td><td><?php if($totalArray[2]>0){echo $totalArray[2];}else{if($abilityArray[2]==0){echo '無';}else{echo '0';}}?></td></tr>
<tr><td>(D1) 檢核與修訂相互的理解</td><td><?php if($totalArray[3]>0){echo $totalArray[3];}else{if($abilityArray[3]==0){echo '無';}else{echo '0';}}?></td></tr>
<tr><td>(A2) 根據目標發現解決問題的互動型態</td><td><?php if($totalArray[4]>0){echo $totalArray[4];}else{if($abilityArray[4]==0){echo '無';}else{echo '0';}}?></td></tr>
<tr><td>(B2) 辨認與描述須完成的工作</td><td><?php if($totalArray[5]>0){echo $totalArray[5];}else{if($abilityArray[5]==0){echo '無';}else{echo '0';}}?></td></tr>
<tr><td>(C2) 訂定計畫</td><td><?php if($totalArray[6]>0){echo $totalArray[6];}else{if($abilityArray[6]==0){echo '無';}else{echo '0';}}?></td></tr>
<tr><td>(D2) 檢核執行的結果與評價解決問題的成功與否</td><td><?php if($totalArray[7]>0){echo $totalArray[7];}else{if($abilityArray[7]==0){echo '無';}else{echo '0';}}?></td></tr>
<tr><td>(A3) 理解解決問題所扮演的角色</td><td><?php if($totalArray[8]>0){echo $totalArray[8];}else{if($abilityArray[8]==0){echo '無';}else{echo '0';}}?></td></tr>
<tr><td>(B3) 描述問題解決中所扮演的角色與團隊組織</td><td><?php if($totalArray[9]>0){echo $totalArray[9];}else{if($abilityArray[9]==0){echo '無';}else{echo '0';}}?></td></tr>
<tr><td>(C3) 遵守制定的規則</td><td><?php if($totalArray[10]>0){echo $totalArray[10];}else{if($abilityArray[10]==0){echo '無';}else{echo '0';}}?></td></tr>
<tr><td>(D3) 檢核、反饋與適應團隊組織和角色</td><td><?php if($totalArray[11]>0){echo $totalArray[11];}else{if($abilityArray[11]==0){echo '無';}else{echo '0';}}?></td></tr>
</table>
</td></tr>
</table>