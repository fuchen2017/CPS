<?php
	session_start();

  //包含需求檔案 ------------------------------------------------------------------------
	include("../class/common_lite.php");
	//宣告變數 ----------------------------------------------------------------------------
	$ODb = new run_db("mysql",3306);      //建立資料庫物件	
	if($_SESSION['loginType'] == ''){
		
	}else{
		switch($_SESSION['loginType']){
			case "ADMIN":
				$keyNum = base64_decode($_POST['keyNum']);
				if(!is_numeric($keyNum)){
					ri_jump("logout.php");
				}
			break;
			default:
			exit;
			break;		
		}	
		
		$sql_dsc = "
		select `a`.*,`b`.`num` as `bnum`,`b`.`c_name` as `teacherName`,`c`.`num` as `cnum`,`c`.`c_title`   
		from `test_time_teacher` as `a` 
		left join `teacherdata` as `b` on `b`.`num`=`a`.`teacherdataNum` 
		left join `main_data` as `c` on `c`.`num`=`a`.`main_data_num` 
		where `a`.`num`='".$keyNum."'
		";
		$res=$ODb->query($sql_dsc) or die("載入資料出錯，請聯繫管理員。");
		while($row = mysql_fetch_array($res)){
			$data['num'] = $row['num'];
			$data['teacherName'] = $row['teacherName'];
			$data['c_title'] = $row['c_title'];
			$data['grade_dsc'] = $row['grade_dsc'];
			$data['class_dsc'] = $row['class_dsc'];
			$data['begin_time'] = $row['begin_time'];
			$data['end_time'] = $row['end_time'];
			$begin_time = substr($row['begin_time'],0,10);
			$end_time= substr($row['end_time'],0,10);
			$dataArray[] = $data;
		}
	}
	$ODb->close();
?>
<table border="0" width="100%">
<tr><td >單元名稱</td>
	<td >教師姓名</td>
	<td >授課年級</td>
	<td >授課班級</td>
	<td >開始時間</td>
	<td >結束時間</td>
</tr>
<?php
for($x=0;$x<count($dataArray);$x++){
$getData = $dataArray[$x];?>
<tr>
<td><?php echo $getData['c_title'];?></td>
<td><?php echo $getData['teacherName'];?></td>
<td><?php echo $getData['grade_dsc'];?></td>
<td><?php echo $getData['class_dsc'];?></td>
<td><input type="text" name="begin<?php echo $x;?>" id="begin<?php echo $x;?>" value="<?php echo $getData['begin_time'];?>"></td>
<td><input type="text" name="end<?php echo $x;?>" id="end<?php echo $x;?>" value="<?php echo $getData['end_time'];?>">
<input type="hidden" name="num<?php echo $x;?>" id="num<?php echo $x;?>" value="<?php echo $getData['num'];?>"></td>
</tr>
<?php	}	?>
<tr>
<td colspan="3" align="center"><input type="button" value="存檔" onclick="saveDiv()"></td>
<td colspan="3" align="center"><input type="button" value="關閉視窗" onclick="$.colorbox.close();"></td>
</tr>
</table>
<script language="javascript">

$(function() {
<?php	for($x=0;$x<count($dataArray);$x++){	?>
  $('#begin<?php echo $x;?>').datetimepicker({dateFormat: 'yy-mm-dd',changeYear : true,changeMonth : true,minDate:'<?php echo $begin_time;?>',maxDate:<?php echo $end_time;?>,timeText: '時間',  
                   hourText: '小時',  
                   minuteText: '分鐘',  
                   secondText: '秒',  
                   currentText: '現在',  
                   closeText: '完成',  
                   showSecond: false
				   });
  $('#end<?php echo $x;?>').datetimepicker({dateFormat: 'yy-mm-dd',changeYear : true,changeMonth : true,minDate:'<?php echo $begin_time;?>',maxDate:'<?php echo $end_time;?>',timeText: '時間',  
                   hourText: '小時',  
                   minuteText: '分鐘',  
                   secondText: '秒',  
                   currentText: '現在',  
                   closeText: '完成',  
                   showSecond: false
				   });
<?php	}	?>
});

var indexNum = <?php echo count($dataArray);?>;//取值得index
function saveDiv(){
var checkErrType=false;
var beginDataArray = new Array();
var endDataArray = new Array();
var numDataArray = new Array();
for(var x=0;x<indexNum;x++){
	var getValue = $('#begin'+x).val();
	if(getValue==''){
		checkErrType=true;
	}
	getValue = $('#end'+x).val();
	if(getValue==''){
		checkErrType=true;
	}
	beginDataArray.push($('#begin'+x).val());
	endDataArray.push($('#end'+x).val());
	numDataArray.push($('#num'+x).val());
}
if(checkErrType){
alert('測驗時間不得為空!!');
}else{
$.ajax({
	    url: './js_function/update_testTime.php',
		type:'POST',
		data: {keyNum:'<?php echo $keyNum;?>',beginData:beginDataArray,endData:endDataArray,numData:numDataArray},		
	    error: function(xhr) {
			alert('Ajax request 發生錯誤');
	    },
	    success: function(response) {
			alert('修改成功!!');
			$.colorbox.close();
			location.replace('testtime_list.php?tr='+nowSWArea);
	    }
  });

  }
  
}

</script>

