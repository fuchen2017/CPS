<?php
	session_start();
//包含需求檔案 ------------------------------------------------------------------------
	include("../class/common_lite.php");
//if($_SESSION['zeroteamzero'] == 'IS_LOGIN'){
	//宣告變數 ----------------------------------------------------------------------------
	$ODb = new run_db("mysql",3306);      //建立資料庫物件	
	if($_POST['userName'] != '' && $_POST['loginName'] != '' && $_POST['loginPw'] != '' && $_POST['swType'] =="insert" && $_POST['tNum'] !=''){
		$userName = $_POST['userName'];
		$loginName = $_POST['loginName'];
		$loginPw = $_POST['loginPw'];
		$tNum = $_POST['tNum'];
		$cityCode = $_POST['cityCode'];
		$cityName = $_POST['cityName'];
		$schoolName = $_POST['schoolName'];
		$educationDsc = $_POST['educationDsc'];
		$gradeDsc = $_POST['gradeDsc'];
		$classDsc = $_POST['classDsc'];
		$studentId = $_POST['studentId'];
		$teacherName = $_POST['tName'];
		$sex = $_POST['sex'];
		//增加單元
		$nowdate =  date("Y-m-d H:i",time());
		$up_dsc ="
		insert into `studentdata` 
		set 
		`loginId`='".$loginName."',
		`pw`='".base64_encode($loginPw)."',
		`c_name`='".$userName."',
		`teacherdataNum`='".$tNum."',
		`city_code`='".$cityCode."',
		`city_name`='".$cityName."',
		`school_name`='".$schoolName."',
		`education_dsc`='".$educationDsc."',
		`grade_dsc`='".$gradeDsc."',
		`class_dsc`='".$classDsc."',
		`student_id`='".$studentId."',
		`sex_dsc`='".$sex."',
		`teacher_name`='".$teacherName."',
		`up_date`='".$nowdate."'";
		$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");	
		
	}
	if($_POST['userName'] != '' && $_POST['loginPw'] != '' && $_POST['swType'] =="update" && $_POST['tNum'] !=''){
		$num = $_POST['num'];
		$userName = $_POST['userName'];
		$loginPw = $_POST['loginPw'];
		$tNum = $_POST['tNum'];
		//增加單元
		$nowdate =  date("Y-m-d H:i",time());
		$up_dsc ="update `studentdata` set `pw`='".base64_encode($loginPw)."',`c_name`='".$userName."',`up_date`='".$nowdate."' where `num`='".$num."' and `teacherdataNum`='".$tNum."' ";
		$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");	
		echo "ok";		
	}	
	
	if($_POST['swType'] =="chkuser" && $_POST['loginName'] != '' && $_POST['tNum'] !=''){
		$loginName = $_POST['loginName'];
		$tNum = $_POST['tNum'];
		
		$sql="select * from `studentdata` where `loginId`='".$loginName."'";
		$res=$ODb->query($sql) or die("載入資料出錯，請聯繫管理員。");
		if(mysql_num_rows($res)>0){
		echo 'error';
		}else{
		echo 'ok';
		}
	}
	
	if($_POST['getNum'] !="" && $_POST['swType'] =="edit" && $_POST['tNum'] !=''){
		$getNum = base64_decode($_POST['getNum']);
		$tNum = $_POST['tNum'];
		
		$sql="select * from `studentdata` where `num`='".$getNum."' and `teacherdataNum`='".$tNum."' ";
		$res=$ODb->query($sql) or die("載入資料出錯，請聯繫管理員。");
		while($row = mysql_fetch_array($res)){
			$getData = array(
			'num'=>$row['num'],
			'loginId'=>$row['loginId'],
			'pw'=>base64_decode($row['pw']),
			'teacherdataNum'=>$row['teacherdataNum'],
			'c_name'=>$row['c_name'],
			'city_code'=>$row['city_code'],
			'city_name'=>$row['city_name'],
			'school_name'=>$row['school_name'],
			'education_dsc'=>$row['education_dsc'],
			'grade_dsc'=>$row['grade_dsc'],
			'class_dsc'=>$row['class_dsc'],
			'student_id'=>$row['student_id'],
			'sex_dsc'=>$row['sex_dsc']
			);
		}
		 echo json_encode($getData);
		
	}
	$ODb->close();
?>