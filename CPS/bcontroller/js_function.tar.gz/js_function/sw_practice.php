<?php
session_start();
//包含需求檔案 ------------------------------------------------------------------------
include("../class/common_lite.php");
//if($_SESSION['zeroteamzero'] == 'IS_LOGIN'){
//宣告變數 ----------------------------------------------------------------------------
$ODb = new run_db("mysql",3306);      //建立資料庫物件
if($_POST['keyNum'] != '' || $_POST['getType'] != ''){
	$sql_dsc = "update `main_data` set `is_practice`='".$_POST['getType']."' where `num`='".$_POST['keyNum']."'";	
	$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");	
	echo 'ok';
}else{
	echo 'ok';
}
$ODb->close();
?>