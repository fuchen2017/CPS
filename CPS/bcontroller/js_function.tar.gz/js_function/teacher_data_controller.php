<?php
	session_start();
//包含需求檔案 ------------------------------------------------------------------------
	include("../class/common_lite.php");
//if($_SESSION['zeroteamzero'] == 'IS_LOGIN'){
	//宣告變數 ----------------------------------------------------------------------------
	$ODb = new run_db("mysql",3306);      //建立資料庫物件	
	if($_POST['userName'] != '' && $_POST['loginName'] != '' && $_POST['loginPw'] != '' && $_POST['swType'] =="insert"){
		$userName = $_POST['userName'];
		$loginName = $_POST['loginName'];
		$loginPw = $_POST['loginPw'];
		
		//增加單元
		$nowdate =  date("Y-m-d H:i",time());
		$up_dsc ="insert into `teacherdata` set `loginId`='".$loginName."',`pw`='".base64_encode($loginPw)."',`c_name`='".$userName."',`up_date`='".$nowdate."'";
		$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");	
		echo "ok";		
	}
	if($_POST['userName'] != '' && $_POST['loginPw'] != '' && $_POST['swType'] =="update"){
		$num = $_POST['num'];
		$userName = $_POST['userName'];
		$loginPw = $_POST['loginPw'];
		
		//增加單元
		$nowdate =  date("Y-m-d H:i",time());
		$up_dsc ="update `teacherdata` set `pw`='".base64_encode($loginPw)."',`c_name`='".$userName."',`up_date`='".$nowdate."' where `num`='".$num."'";
		$res = $ODb->query($up_dsc) or die("更新資料出錯，請聯繫管理員。");	
		echo "ok";		
	}	
	
	if($_POST['swType'] =="chkuser" && $_POST['loginName'] != ''){
		$loginName = $_POST['loginName'];
		$sql="select * from `teacherdata` where `loginId`='".$loginName."' ";
		$res=$ODb->query($sql) or die("載入資料出錯，請聯繫管理員。");
		if(mysql_num_rows($res)>0){
		echo 'error';
		}else{
		echo 'ok';
		}
	}
	
	if($_POST['getNum'] !="" && $_POST['swType'] =="edit"){
		$getNum = base64_decode($_POST['getNum']);
		$sql="select * from `teacherdata` where `num`='".$getNum."' ";
		$res=$ODb->query($sql) or die("載入資料出錯，請聯繫管理員。");
		while($row = mysql_fetch_array($res)){
			$getData = array(
			'num'=>$row['num'],
			'loginId'=>$row['loginId'],
			'pw'=>base64_decode($row['pw']),
			'schoolNum'=>$row['schoolNum'],
			'c_name'=>$row['c_name']
			);
		}
		 echo json_encode($getData);
		
	}
$ODb->close();
?>