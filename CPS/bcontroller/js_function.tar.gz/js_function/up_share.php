<?php
session_start();
//包含需求檔案 ------------------------------------------------------------------------
include("../class/common_lite.php");
//宣告變數 ----------------------------------------------------------------------------
$ODb = new run_db("mysql",3306);      //建立資料庫物件

if($_SESSION['loginType'] == ''){

}else{
	$nowdate =  date("Y-m-d H:i",time());
	$sql_dsc = "insert into `share_data`(`user_num`,`user_type`,`mainData_num`,`up_date`) values ";
	switch($_SESSION['loginType']){
		case "ADMIN":
			if($_POST['keyNum'] != ''){
				$sarray = explode(',',substr($_POST['keyNum'],0,-1));				
				foreach($sarray as $value){
					$tempDsc .="(0,'ADMIN','".$value."','".$nowdate."'),";
				}
				$sql_dsc.= substr($tempDsc,0,-1);
				$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");	
				echo 'ok';
			}else{
				echo 'ok';
			}
		break;
		case "TEACHER":
			if($_POST['keyNum'] != ''){
				$sarray = explode(',',substr($_POST['keyNum'],0,-1));				
				foreach($sarray as $value){
					$tempDsc .="(".$_SESSION['swTeacherNum'].",'TEACHER','".$value."','".$nowdate."'),";
				}
				$sql_dsc.= substr($tempDsc,0,-1);
				$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");	
				echo 'ok';
			}else{
				echo 'ok';
			}		
		break;
		default:
		echo 'ok';
		break;		
	}
}	
$ODb->close();
?>