<?php
session_start();
//包含需求檔案 ------------------------------------------------------------------------
include("../class/common_lite.php");
//if($_SESSION['zeroteamzero'] == 'IS_LOGIN'){
//宣告變數 ----------------------------------------------------------------------------
$ODb = new run_db("mysql",3306);      //建立資料庫物件
if($_POST['keyNum'] != '' || $_POST['recordData'] != ''){
	$up_dsc="";
	$addDsc="";
	if($_POST['recordData'] !=""){
		$up_dsc = substr($_POST['recordData'],0,-4);
	}
	
	switch($_POST['testUserType']){
		case "ADMIN":
		$whereDSc = " where `create_user_type`='ADMIN' and `main_data_num`='".$_POST['keyNum']."' ";
		$addDsc .= ",`create_user_type`='".$_POST['testUserType']."'";
		break;
		case "TEACHER":
		$whereDSc = " where `create_user_type`='TEACHER' and `main_data_num`='".$_POST['keyNum']."' and `teacher_user`='".$_POST['testUser']."' ";
		$addDsc .= ",`create_user_type`='".$_POST['testUserType']."'";
		if($_POST['testUser']>''){
			$addDsc .= ",`teacher_user`='".$_POST['testUser']."'";
		}
		
		break;
		case "STUDENT":
		$whereDSc = " where `create_user_type`='STUDENT' and `main_data_num`='".$_POST['keyNum']."' and `teacher_user`='".$_SESSION['teacherdataNum']."' and `student_user`='".$_POST['testUser']."' ";
		
		$addDsc .= ",`create_user_type`='".$_POST['testUserType']."'";
		if($_POST['testUser']>''){
			$addDsc .= ",`teacher_user`='".$_SESSION['teacherdataNum']."',`student_user`='".$_POST['testUser']."'";
		}		
		break;
		default:
		break;
		
	}
	//先判斷此題目是否為練習題目，若是練習題則判斷是否新增或是覆蓋就有資料
	$sql_dsc = "select * from `main_data` where `num`='".$_POST['keyNum']."' and `is_practice`='1'";	
	$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");
	if(mysql_num_rows($res)==1){
		$sql_dsc = "select * from `opt_record` ".$whereDSc." order by `num` desc limit 1";	
		$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");
		if(mysql_num_rows($res)==1){
		while($row = mysql_fetch_array($res)){
		$keyNum = $row['num'];
		}
		//更新資料
		$sql_dsc = "
		update `opt_record` 
		set 
		`record_value`='".$up_dsc."',
		`test_begin_time`='".$_POST['testBeginTime']."',
		`power_dsc`='".$_SESSION['testPowerValue']."',
		`up_date`='".date("Y-m-d H:i",time())."' 
		where `num`='".$keyNum."' and `main_data_num`='".$_POST['keyNum']."'";	
		$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");	
		}else{
			//新增資料
			$sql_dsc = "insert into `opt_record` set `main_data_num`='".$_POST['keyNum']."',`timelist_dsc`='練習題目',`record_value`='".$up_dsc."',`test_begin_time`='".$_POST['testBeginTime']."',`power_dsc`='".$_SESSION['testPowerValue']."',`up_date`='".date("Y-m-d H:i",time())."'".$addDsc;	
			$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");
		}

	}else{
		//如果是學生的話就查詢當次測試清單的名稱與key值
		$default_num =0;
		$default_dsc ='';
		if($_POST['testUserType']=="STUDENT"){
			$sql_dsc = "
			select `a`.*,`b`.`num`,`b`.`c_title` 
			from `test_time_teacher` as `a`
			left join `test_time_list` as `b` on `b`.num=`a`.`f_num` 
			where `a`.`main_data_num`='".$_POST['keyNum']."' and `a`.`teacherdataNum`='".$_SESSION['teacherdataNum']."' and `a`.`grade_dsc`='".$_SESSION['grade_dsc']."' and `a`.`class_dsc`='".$_SESSION['class_dsc']."'";	 
			$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");
			while($row = mysql_fetch_array($res)){
				$default_num =$row['f_num'];
				$default_dsc =$row['c_title'];
			}
		}
	
		//新增資料
		$sql_dsc = "
		insert into `opt_record` 
		set 
		`main_data_num`='".$_POST['keyNum']."',
		`record_value`='".$up_dsc."',
		`test_begin_time`='".$_POST['testBeginTime']."',
		`power_dsc`='".$_SESSION['testPowerValue']."',
		`timelist_num`='".$default_num."',
		`timelist_dsc`='".$default_dsc."',
		`up_date`='".date("Y-m-d H:i",time())."'".$addDsc;	
		$res = $ODb->query($sql_dsc) or die("更新資料出錯，請聯繫管理員。");
	}
	$_SESSION['testPowerValue']='';	
	echo json_encode('ok');
}else{
	echo json_encode('ok');
}
$ODb->close();
?>