<?php
session_start();
//包含需求檔案 ------------------------------------------------------------------------
include("../class/common_lite.php");
if($_SESSION['loginType'] == ''){
	ri_jump("logout.php");
}else{
	switch($_SESSION['loginType']){
		case "ADMIN":	
		break;
		default:
		ri_jump("logout.php");
		break;		
	}	
}	
//宣告變數 ----------------------------------------------------------------------------
$ODb = new run_db("mysql",3306);      //建立資料庫物件
if($_POST['keyNum'] != '' && $_POST['beginData'] != ''&& $_POST['endData'] != ''&& $_POST['numData'] != ''){
	$keynum = $_POST['keyNum'];
	$begindata= $_POST['beginData'];
	$enddata= $_POST['endData'];
	$numdata= $_POST['numData'];
	for($x=0;$x<count($numdata);$x++){
		$sqlDsc="update `test_time_teacher` set `begin_time`='".$begindata[$x]."',`end_time`='".$enddata[$x]."' where `num`='".$numdata[$x]."'";
		$res=$ODb->query($sqlDsc) or die("載入資料出錯，請聯繫管理員。");
	}	
	
	echo 'ok';
}else{
	echo 'ok';
}
$ODb->close();
?>