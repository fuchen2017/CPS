<?php		
if($_POST['values'] !=''){
$get_value=base64_encode($_POST['values']);
$get_value = str_replace("+",urlencode('+'),$get_value);
$get_value = str_replace("/",urlencode('/'),$get_value);
echo $get_value;//使用新的編碼去加密
}else{
echo '';
}


?>